# Express file upload api

## Installing packages

- `npm install`

## Starting server

- `npm run server`

> server is running at port 4500

## Api route

- `http://localhost:4500/upload`
